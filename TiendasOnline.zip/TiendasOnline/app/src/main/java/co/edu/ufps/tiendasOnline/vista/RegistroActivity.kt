package co.edu.ufps.tiendasOnline.vista

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import co.edu.ufps.tiendasOnline.R

class RegistroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }
}