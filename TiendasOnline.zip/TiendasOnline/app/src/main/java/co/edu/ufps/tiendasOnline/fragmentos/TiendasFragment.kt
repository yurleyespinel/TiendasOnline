package co.edu.ufps.tiendasOnline.fragmentos

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import co.edu.ufps.tiendasOnline.R
import co.edu.ufps.tiendasOnline.controller.TiendaAdapter
import co.edu.ufps.tiendasOnline.entity.Tienda

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [TiendasFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class TiendasFragment : Fragment() {

    //variable para hacer el find by
    lateinit var contenedorTienda:RecyclerView
    lateinit var tiendaAdapter : TiendaAdapter

    private var param1: String?=null
    private var param2: String?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    //inicializamos el recyclerview que creamos
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view =inflater.inflate(R.layout.fragment_tiendas, container, false)
        contenedorTienda = view.findViewById(R.id.contenedor_tienda)
        var linearLayout = LinearLayoutManager(context)
        linearLayout.orientation= LinearLayoutManager.VERTICAL
        contenedorTienda.layoutManager = linearLayout
        tiendaAdapter = TiendaAdapter(context,dataSet(), R.layout.card)
        contenedorTienda.adapter = tiendaAdapter

        return view
    }

    private fun dataSet(): ArrayList<Tienda> {
        var tiendas: ArrayList<Tienda> = java.util.ArrayList()
        val nombres = arrayOf("https://img.freepik.com/vector-gratis/carro-tienda-edificio-tienda-dibujos-animados_138676-2085.jpg",
            "https://static.wikia.nocookie.net/logopedia/images/0/0e/Justo%26BuenoColombia.png/revision/latest/scale-to-width-down/2000?cb=20210308214413&path-prefix=es",
            "https://anapinzon.com/wp-content/uploads/2017/07/logo-ara.png",
            "https://upload.wikimedia.org/wikipedia/commons/a/a8/Tiendas_D1_logo.png",
        "https://upload.wikimedia.org/wikipedia/commons/a/a8/Tiendas_D1_logo.png")
        for (i in 1..5){
            var tienda = Tienda("$i","Tienda $i", "Tienda $i descripcion",
                nombres[i-1],0.0,0.0,"32$i"+"563$i"+"156")

            tiendas.add(tienda)
        }
        return tiendas
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment TiendasFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TiendasFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}