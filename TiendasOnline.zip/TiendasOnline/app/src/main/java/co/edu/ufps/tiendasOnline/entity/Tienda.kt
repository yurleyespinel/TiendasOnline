package co.edu.ufps.tiendasOnline.entity


//Datos que va a recibir
data class Tienda(val id:String,
                  val nombre:String,
                  val descripcion:String,
                  val imagen:String,
                  val latitud:Double,
                  val longitud:Double,
                  val telefono:String)
